# RecoveryEval: Independent Scientific Evidence Package

This standalone package provides all primary empirical observations, benchmark definitions, reproduction code, and statistical certifications for:

**RecoveryEval: Evaluating Continuation Inertia Under Injected Reasoning Errors in Large Language Models**  
*Principal Investigator*: Sham Satish Thakare (shamthakare@gmail.com)

## Quickstart Reproduction (Offline, 0 Dependencies)

Prerequisites: Python 3.9+ (Standard Library only).

```bash
# 1. Verify file checksums
shasum -a 256 -c MANIFEST_SHA256.txt

# 2. Execute reproduction engine
python3 verification/reproduce_from_raw.py
```

Expected execution time: < 1.0 second.
Produces:
- `verification/experimental_matrix.csv` (400-row observation matrix)
- `verification/verified_results.json` (Structured statistical findings)
- `verification/reproduction.log` (Execution summary)
