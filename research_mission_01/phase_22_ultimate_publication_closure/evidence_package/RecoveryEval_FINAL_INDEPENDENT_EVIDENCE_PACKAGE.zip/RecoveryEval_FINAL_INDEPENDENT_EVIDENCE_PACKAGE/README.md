# RecoveryEval: Independent Scientific Evidence Package

This package provides all primary observations, benchmark definitions, reproduction scripts,
and statistical certifications for:

**RecoveryEval: Evaluating Continuation Inertia Under Injected Reasoning Errors in Large Language Models**  
*Principal Investigator*: Sham Satish Thakare (shamthakare@gmail.com)

## Quickstart Reproduction (Offline, Zero External Dependencies)

Prerequisites: Python 3.9+ (Standard Library only).

```bash
# 1. Verify package manifest
shasum -a 256 -c MANIFEST_SHA256.txt

# 2. Execute reproduction engine
python3 verification/reproduce_from_raw.py
```

Expected execution time: < 1.0 second on standard CPU hardware.
Produces:
- `verification/experimental_matrix.csv` (400-row observation matrix)
- `verification/verified_results.json` (Structured empirical findings)
- `verification/reproduction.log` (Audit trace)
