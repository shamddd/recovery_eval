# Manuscript Data Traceability Matrix

Every empirical value in `RecoveryEval_FINAL_arXiv.pdf` traces to bit-exact primary records:
- 400 rollouts -> len(10_COMPLETE_QWEN_PROTOCOL2_ROLLOUTS.jsonl)
- 100.0% Control -> verified_results.json
- 0.0% Recovery -> verified_results.json
- 98.5% Propagation -> verified_results.json
- 1.5% Divergence -> verified_results.json (Instruct fresh_004 seeds 401, 403, 405)
- <= 13.91% Cluster Bound -> verified_results.json
- Delta_chars = 0 -> BALANCED_PROMPT_REGISTRY.json
