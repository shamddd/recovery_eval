# Causal Identification and SUTVA Certification

- **Framework**: Rubin Potential Outcomes Y_i(t; m, s).
- **Intervention**: Deterministic prefix token corruption with Delta_chars = 0.
- **SUTVA**: Isolated, stateless model inference sessions preclude interference across rollouts.
- **Scope**: Finite-sample observed contrast Delta_hat = -1.0000 on the evaluated benchmark instances.
- **Observational Separation**: Base vs. Instruct contrast reflects distinct training checkpoints, not a causal ablation of instruction tuning.
