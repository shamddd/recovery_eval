# Statistical Inference and Degenerate Variance Certification

1. **Exact Clopper-Pearson 95% Confidence Intervals**:
   - Control Accuracy: 200/200 (100.0%) -> [98.17%, 100.00%]
   - Spontaneous Recovery: 0/200 (0.0%) -> [0.00%, 1.83%]
   - 1-Sided Recovery Upper Bound: <= 1.49% (1 - 0.05^(1/200))
   - Error Propagation: 197/200 (98.5%) -> Base: 100%, Instruct: 97%
   - Alternative Divergence: 3/200 (1.5%) -> Base: 0%, Instruct: 3%

2. **Cluster Sensitivity Bound**:
   - Problem-level recovery prevalence across N=20 independent clusters: <= 13.91% (1 - 0.05^(1/20)).

3. **Degenerate Variance Singularity**:
   - Paired contrast: Delta_hat = -1.0000, sample SD s_D = 0.0000, SE = 0.0000.
   - For testing H0: Delta = 0, t = (-1.0000 - 0) / 0.0000 -> division by zero standard error (-1/0 singularity).
   - Conventional Student t-tests and asymptotic Wald CIs are degenerate and invalid.
