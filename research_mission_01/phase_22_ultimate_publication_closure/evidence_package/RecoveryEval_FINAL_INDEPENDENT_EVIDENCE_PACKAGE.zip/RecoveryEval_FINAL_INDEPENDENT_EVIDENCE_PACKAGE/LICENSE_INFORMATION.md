# License Information

- **Code & Verification Scripts**: Licensed under the MIT License / Apache 2.0.
- **Dataset (`data/10_COMPLETE_QWEN_PROTOCOL2_ROLLOUTS.jsonl`)**: Creative Commons Attribution 4.0 International (CC BY 4.0).
- **Benchmark Registry (`benchmark/BALANCED_PROMPT_REGISTRY.json`)**: Creative Commons Attribution 4.0 International (CC BY 4.0).
- **Research Manuscript (`manuscript/RecoveryEval_FINAL_arXiv.pdf`)**: Open-access preprint; all rights reserved by the author for preprint distribution under arXiv Non-Exclusive License.
