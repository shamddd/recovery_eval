# Primary Dataset Forensic Audit

- **File**: `data/10_COMPLETE_QWEN_PROTOCOL2_ROLLOUTS.jsonl`
- **File Size**: 382,803 bytes
- **SHA-256**: `b8792f8df375fccdbd800d440cc884ef2db2f860ff3533af01c70161a5cc1d15`
- **Total Records**: Exactly 400 lines (valid JSON).
- **Unique Rollout IDs**: 400 (zero duplicates).
- **Truncation**: 0 records truncated (`truncated == False`).
- **EOS Hit**: 100% records terminated naturally (`eos_hit == True`).
- **Models**:
  1. `Qwen/Qwen2.5-Math-1.5B` (100 control, 100 recovery)
  2. `Qwen/Qwen2.5-Math-1.5B-Instruct` (100 control, 100 recovery)
- **Seeds**: `[401, 402, 403, 404, 405]`
- **Problems**: `gsm8k_fresh_000` through `gsm8k_fresh_019` (20 problems).
