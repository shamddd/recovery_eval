# Statistical Methodology and Derivations

## Primary Empirical Outcomes
- Control Accuracy (T=0): 200/200 = 100.0% (95% Clopper-Pearson CI: [98.17%, 100.00%])
- Recovery Rate (T=1): 0/200 = 0.0% (95% Clopper-Pearson CI: [0.00%, 1.83%])
- Error Propagation Rate (T=1): 197/200 = 98.5% (Base: 100/100, Instruct: 97/100)
- Alternative Divergence Rate (T=1): 3/200 = 1.5% (Base: 0/100, Instruct: 3/100 on fresh_004)

## Exact Non-Parametric Bounds
1. **Rollout-Level Upper Bound**:
   (1 - p)^200 = 0.05 => p <= 1 - 0.05^(1/200) approx 1.488% <= 1.49% (one-sided 95%).
2. **Problem Cluster-Level Sensitivity Bound**:
   (1 - p)^20 = 0.05 => p <= 1 - 0.05^(1/20) approx 13.911% <= 13.91% (one-sided 95%).

## Degenerate Variance
- Every paired difference D_i = Y_i(1) - Y_i(0) = 0 - 1 = -1.0000.
- Sample standard deviation s_D = 0.0000.
- Student's t statistic is undefined (0/0).
