# Complete Manuscript Data Traceability Matrix

| Manuscript Location | Exact Reported Claim | Primary Source Artifact | Verified Value | Match Status |
| :--- | :--- | :--- | :--- | :---: |
| Abstract | 400 rollouts, 2 models, 20 problems, 5 seeds | `10_COMPLETE_QWEN_PROTOCOL2_ROLLOUTS.jsonl` | 400 rollouts, 2x20x5 | VERIFIED |
| Abstract | Control accuracy: 100.0% (200/200) | `independent_results.json` | 200/200 (100.0%) | VERIFIED |
| Abstract | Recovery rate: 0.0% (0/200) | `independent_results.json` | 0/200 (0.0%) | VERIFIED |
| Abstract | Error propagation: 98.5% (197/200) | `independent_results.json` | 197/200 (98.5%) | VERIFIED |
| Abstract | Alternative divergence: 1.5% (3/200) | `independent_results.json` | 3/200 (1.5%) | VERIFIED |
| Abstract | 95% Clopper-Pearson CI: [0.00%, 1.83%] | Exact binomial formula (k=0, n=200) | [0.00%, 1.83%] | VERIFIED |
| Abstract | Cluster sensitivity bound: <= 13.91% | Exact cluster formula (1 - 0.05^(1/20)) | <= 13.91% | VERIFIED |
| Section 4.3 | fresh_000: 5/hr * 4 hrs @ $4 -> gold $80 | `BALANCED_PROMPT_REGISTRY.json` | 5*4=20, 20*4=80 | VERIFIED |
| Section 5.1 | Table 4: Base prop 100%, Instruct prop 97% | `experimental_matrix.csv` | 100/100 vs 97/100 | VERIFIED |
| Section 5.2 | Historical interaction non-reproduced | `independent_results.json` | Sample contrast D=0.0000 | VERIFIED |
| Section 5.3 | Heuristic verifier 3 false negatives | Rollouts fresh_004, 006, 013 s405 | 3 false negatives | VERIFIED |
| Section 5.4 | Divergences: 3 rollouts on fresh_004 | Instruct s401, s403, s405 on fresh_004 | 3 divergences | VERIFIED |
| Appendix A | Table 5: All 20 problem parameters | `BALANCED_PROMPT_REGISTRY.json` | 20 problems verified | VERIFIED |
