# Benchmark Registry Forensic Audit

- **File**: `benchmark/BALANCED_PROMPT_REGISTRY.json`
- **File Size**: 44,048 bytes
- **SHA-256**: `d312bea07a4985ee49176e51ad0eea3a99f7445325c375561ac69b1871a2f08c`
- **Problem Count**: 20 distinct synthetic arithmetic problems.
- **Prefix Length Symmetry**: Character length delta is 0 for all 20 problems.
- **Canonical Example (gsm8k_fresh_000)**:
  - Rate: 5 notebooks/hour
  - Duration: 4 hours
  - Price: $4/notebook
  - Correct Step 1: 5 * 4 = 20 notebooks
  - Injected Step 1: 5 * 4 = 22 notebooks
  - Gold Final Answer: 20 * $4 = $80
  - Corrupted Continuation Target: 22 * $4 = $88
- **Arithmetic Verification**: 100% of the 20 problems satisfy Rate * Duration = Correct Intermediate, Correct Intermediate * Price = Gold Answer, and Injected Intermediate = Correct Intermediate + 2.
