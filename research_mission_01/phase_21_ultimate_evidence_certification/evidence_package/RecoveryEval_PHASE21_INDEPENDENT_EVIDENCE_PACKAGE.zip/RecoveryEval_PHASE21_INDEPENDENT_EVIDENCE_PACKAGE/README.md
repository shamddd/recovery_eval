# RecoveryEval: Independent Evidence & Reproduction Package (Phase XXI)

**Principal Investigator**: Sham Satish Thakare (shamthakare@gmail.com)  
**Paper Title**: RecoveryEval: Evaluating Continuation Inertia Under Injected Reasoning Errors in Language Models  
**Canonical Repository**: https://github.com/shamddd/recovery_eval  

---

## 1. Overview

This self-contained package contains the primary frozen empirical dataset, canonical benchmark prompt registry, reproduction script, and forensic audit reports required for independent external reproduction.

### Package Structure
```
RecoveryEval_PHASE21_INDEPENDENT_EVIDENCE_PACKAGE/
|-- README.md                                # Package documentation
|-- MANIFEST_SHA256.txt                      # Checksums of all package files
|-- data/
|   `-- 10_COMPLETE_QWEN_PROTOCOL2_ROLLOUTS.jsonl   # 400 primary rollout records
|-- benchmark/
|   `-- BALANCED_PROMPT_REGISTRY.json        # 20 verified GSM-fresh problems
|-- verification/
|   |-- reproduce_from_raw.py                # Standalone reproduction script
|   |-- independent_results.json             # Serialized recomputation results
|   |-- experimental_matrix.csv              # Full 400-cell experimental matrix
|   |-- reproduction.log                     # Verbatim execution trace
|   `-- requirements.txt                     # Python dependencies
|-- manuscript/
|   `-- RecoveryEval_PHASE21_FINAL_arXiv.pdf # 17-page certified preprint PDF
`-- reports/
    |-- dataset_audit.md                     # Forensic record-level audit
    |-- benchmark_audit.md                   # Problem arithmetic verification
    |-- statistical_audit.md                 # Derivations and confidence intervals
    `-- manuscript_traceability.md           # Claim-by-claim verification table
```

---

## 2. Reproduction Instructions

1. **Install Dependencies**:
   ```bash
   pip install -r verification/requirements.txt
   ```

2. **Execute Reproduction Script**:
   ```bash
   python3 verification/reproduce_from_raw.py
   ```

3. **Verify Expected Empirical Results**:
   - Total rollouts: 400 (2 models, 2 conditions, 20 problems, 5 seeds)
   - Control Accuracy (T=0): 100.0% (200 / 200, 95% CI [98.17%, 100.00%])
   - Recovery Rate (T=1): 0.0% (0 / 200, 95% CI [0.00%, 1.83%])
   - Error Propagation (T=1): 98.5% (197 / 200)
   - Alternative Divergence (T=1): 1.5% (3 / 200)
   - Rollout 95% One-Sided Upper Bound: <= 1.49%
   - Problem Cluster Sensitivity Bound (N=20): <= 13.91%
