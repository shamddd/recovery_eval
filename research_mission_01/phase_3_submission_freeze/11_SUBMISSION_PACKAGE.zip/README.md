# IEEE MLBD 2026 Submission Package: recovery_eval

**Paper Title**: recovery_eval: State-Matched and Provenance-Aware Evaluation of Recovery Behavior in Language-Model Reasoning  
**Author**: Sham Satish Thakare  
**Submission Identifier**: BigD497 (IEEE BigData 2026 Tracking)  
**Target Venue**: 11th IEEE Special Session on Machine Learning on Big Data (MLBD 2026)  
**Document Class**: IEEEtran (10pt, two-column, letter paper)  
**Page Count**: Strictly 5.0 pages (including all figures, tables, and 15 references)  

## Package Contents
1. `main.tex`: Master LaTeX source file conforming to IEEEtran conference format.
2. `main.pdf`: Authoritative 5.0-page compiled PDF document.
3. `references.bib`: Complete BibTeX database containing all 15 audited citations.
4. `IEEEtran.cls`: Official IEEE conference class file (version 1.8b).
5. `IEEEtran.bst`: Official IEEE bibliography style file.
6. `figures/`: Vector PDF figures:
   - `fig1_architecture.pdf`: System governance and evaluation pipeline architecture.
   - `fig2_state_construction.pdf`: Matched state construction and perturbation injection.
   - `fig3_provenance_chain.pdf`: Cryptographic append-only primitive evidence chain.
   - `fig4_empirical_results.pdf`: Empirical continuation outcomes and matched contrast.

## Compilation Instructions
To reproduce `main.pdf` from source:
```bash
# Using standard tectonic compiler:
tectonic main.tex

# Or using standard pdflatex / bibtex toolchain:
pdflatex main
bibtex main
pdflatex main
pdflatex main
```
